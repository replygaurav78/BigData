from mrjob.job import MRJob
import re

WORD_RE = re.compile(r"[\w']+")

class MRGramCounter(MRJob):
    
    
    def mapper(self, _ , line):
        #yield "chars", len(line)
        i=0
        p=0
        wordcheck=[]
        bigram=[]
        trigram =[]
        wordcheck=line.split()
        m=len(wordcheck)
        yield "monograms", m
        for word in wordcheck[i:]:
            if m>i+1 :
                bigram.append(wordcheck[i]+wordcheck[i+1])
                i=i+1
        #for word in re.findall(WORD_RE,"  ".join(bigram)):
        yield "bigrams",len(bigram)
		
        for word in wordcheck[p:]:
            if m>p+2 :
                trigram.append(wordcheck[p]+wordcheck[p+1]+wordcheck[p+2])
                p=p+1
        yield "trigrams",len(trigram)
		
    #def combiner(self, word, counts):
        #yield word, sum(counts)

    #def reducer(self, word, counts):
		#yield word, sum(counts)
		
		    

if __name__ == '__main__':
    MRGramCounter.run()