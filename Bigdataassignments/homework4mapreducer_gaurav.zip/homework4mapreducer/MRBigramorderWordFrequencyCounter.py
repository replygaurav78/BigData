from mrjob.job import MRJob
from mrjob.step import MRStep
from collections import defaultdict
from collections import Counter
from operator import itemgetter
import re
from operator import itemgetter

WORD_RE = re.compile(r"[\w']+")

class MRWordFrequencyCountnew_1(MRJob):

      def steps(self) :
          return [
              MRStep(mapper=self.mapper_get_words,
                     combiner=self.combiner_get_words,
                     reducer=self.reducer_get_words),
              MRStep(reducer=self.reducer_find_max_10_words)
        ]
    
      def mapper_get_words(self, _ , line):
          i=0 
          wordcheck=[]
          bigram=[]
          wordcheck=line.split()
          m=len(wordcheck)
          for word in wordcheck[i:] :
              if m>i+1 :
                 bigram.append(wordcheck[i]+wordcheck[i+1])
                 i=i+1
          for word in re.findall(WORD_RE,"  ".join(bigram)) :
              yield word.lower(),1
        
      def combiner_get_words(self, word, counts) :
          yield word, sum(counts)

      def reducer_get_words(self, word, counts) :
          yield  None,(sum(counts),word)
		  #yield None,(word, sum(counts))

      def reducer_find_max_10_words(self, _ , word_count_pairs):
          lst=list(word_count_pairs)
          lst.sort()
          lst.reverse()
          return lst[0:10]
          

if __name__ == '__main__':
    MRWordFrequencyCountnew_1.run()