from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.selector import HtmlXPathSelector
from scrapy.exceptions import CloseSpider
from scrapy.xlib.pydispatch import dispatcher
from testspiders.items import TestspidersItem
import numpy, logging
from scrapy import signals


class MySpider(CrawlSpider):
    name = "pagerank"    
    allowed_domains = ["dice.com"]
    start_urls = ["https://www.dice.com/jobs?q=Computer+science&l=Philadelphia%2C+PA&searchid=4203982346226"]
    urls=[]
    pageLimit=200
    stochasticMatrix= numpy.zeros((pageLimit+1,pageLimit+1))
    rules = (
        Rule(SgmlLinkExtractor(), callback="parse_items", follow= True),
    )

    def pagerank(self, H):
        n= len(H)
        w = numpy.zeros(n)
        rho = 1./n * numpy.ones(n);
        for i in range(n):
          if numpy.multiply.reduce(H[i]== numpy.zeros(n)):
            w[i] = 1
        newH = H + numpy.outer((1./n * w),numpy.ones(n))
     
        theta=0.85
        G = (theta * newH) + ((1-theta) * numpy.outer(1./n * numpy.ones(n), numpy.ones(n)))
        for j in range(10):
            rho = numpy.dot(rho,G)
        print ("\n\n\\top 5 urls")
        print "\n\n".join([self.urls[i] for i in rho.argsort()[-5:][::-1]])
    print ("\n\\finished")      
    def parse_start_url(self, response):
        self.crawler.signals.connect(self.spider_closed, signal=signals.spider_closed)
        self.parse_items(response)
        
    def parse_items(self, response):
        hxs = HtmlXPathSelector(response)
        titles = hxs.select("//div[@class='serp-result-content']")
        parenturl = response.request.url

        if self.pageLimit <= 0:
            raise CloseSpider('Limit Reached')          
        if len(titles) >= self.pageLimit:
            titles=list(titles)[:self.pageLimit]
            self.pageLimit=0
        else:
            self.pageLimit=self.pageLimit-len(titles)
        for titles in titles:
            item = TestspidersItem()
            item["title"] = titles.select("h3/a/@title").extract()
            #item["link"] = "https://www.dice.com/jobs?q=Computer+science&l=Philadelphia%2C+PA&searchid=4203982346226"+"".join(titles.select("h3/a/@href").extract())
            item["link"] = "".join(titles.select("h3/a/@href").extract())
            item["parent"] = parenturl
            #item["title"] = titles.select("h3/a/@title").extract()
            #partialLink="".join(titles.select("h3/a/@href").extract())
            #item["link"] = str("https://www.dice.com/jobs?q=Computer+science&l=Philadelphia%2C+PA&searchid=4203982346226"+( '' if partialLink[0]=='/' else '/') +partialLink) 
            #item["parent"] = parenturl
            yield item
            
            try:
                if item["parent"] in self.urls:
                     n= self.urls.index(item["parent"])
                else:
                    self.urls.append(item["parent"])
                    n= self.urls.index(item["parent"])
                    
                if item["link"] in self.urls:
                    m= self.urls.index(item["link"])
                else:
                    self.urls.append(item["link"])
                    m= self.urls.index(item["link"])
                self.stochasticMatrix[n,m]=1.0
            except: 
                print "exception ", item["link"]," ", parenturl
        
    def spider_closed(self, spider):
        numpy.set_printoptions(linewidth=150)
        i=0
        for row in self.stochasticMatrix:
            s=numpy.sum(row)
            if s!=0:
                j=0
                for ele in row:
                   self.stochasticMatrix[i,j]=ele/s
                   j+=1
            i+=1
        self.pagerank(self.stochasticMatrix)
