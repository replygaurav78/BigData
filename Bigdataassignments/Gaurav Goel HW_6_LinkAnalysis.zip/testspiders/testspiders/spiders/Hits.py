from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.selector import HtmlXPathSelector
from scrapy.exceptions import CloseSpider
from scrapy.xlib.pydispatch import dispatcher
from testspiders.items import TestspidersItem
import numpy, logging
from scrapy import signals

class MySpider(CrawlSpider):
    name = "hits"    
    allowed_domains = ["dice.com"]
    start_urls = ["https://www.dice.com/jobs?q=Computer+science&l=Philadelphia%2C+PA&searchid=4203982346226"]
    urls=[]
    pageLimit=200
    stochasticMatrix= numpy.zeros((pageLimit+1,pageLimit+1))
    rules = (
        Rule(SgmlLinkExtractor(), callback="parse_items", follow= True),
    )

    def hits(self, A):
        n= len(A)
        Au= numpy.dot(numpy.transpose(A),A)
        Hu = numpy.dot(A,numpy.transpose(A))
        a = numpy.ones(n); h = numpy.ones(n)
        for j in range(5):
            a = numpy.dot(a,Au)
            a= a/sum(a)
            h = numpy.dot(h,Hu)
            h = h/ sum(h)
#        print a.argsort()[-5:][::-1],'\n',h.argsort()[-5:][::-1]
        print ("top 5 urls")
        print "\n\n\n".join([self.urls[i] for i in a.argsort()[-5:][::-1]])
	print ("\n\finished")
    def parse_start_url(self, response):
        self.crawler.signals.connect(self.spider_closed, signal=signals.spider_closed)
        self.parse_items(response)
        
    def parse_items(self, response):
        hxs = HtmlXPathSelector(response)
        titles = hxs.select("//div[@class='serp-result-content']")
        parenturl = response.request.url

        if self.pageLimit <= 0:
            raise CloseSpider('Limit Reached')          
        if len(titles) >= self.pageLimit:
            titles=list(titles)[:self.pageLimit]
            self.pageLimit=0
        else:
            self.pageLimit=self.pageLimit-len(titles)
        for titles in titles:
            item = TestspidersItem()
            #item["title"] = titles.xpath("a/@title").extract()
            #item["link"] = "http://www.indeed.com/jobs?q=jobs&l=Philadelphia%2C+PA"+"".join(titles.xpath("a/@href").extract())
            item["title"] = titles.select("h3/a/@title").extract()
            #item["link"] = "https://www.dice.com/jobs?q=Computer+science&l=Philadelphia%2C+PA&searchid=4203982346226"+"".join(titles.select("h3/a/@href").extract())
            item["link"] = "".join(titles.select("h3/a/@href").extract())
            item["parent"] = parenturl
            yield item
            
            try:
                if item["parent"] in self.urls:
                     n= self.urls.index(item["parent"])
#                    m=10
                else:
                    self.urls.append(item["parent"])
                    n= self.urls.index(item["parent"])
    #                n=1
                    
                if item["link"] in self.urls:
                    m= self.urls.index(item["link"])
#                    m=10
                else:
                    self.urls.append(item["link"])
                    m= self.urls.index(item["link"])
#                    print m
#                    m=5
                self.stochasticMatrix[n,m]=1.0
                self.stochasticMatrix[m,n]=1.0 
            except: 
                print "exception ", item["link"]," ", parenturl
        
    def spider_closed(self, spider):
        for url in self.urls:
            print url,'\n'
			#print self.urls[1:5]
        numpy.set_printoptions(linewidth=2000)
        self.hits(self.stochasticMatrix)
