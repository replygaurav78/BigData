from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors.sgml import SgmlLinkExtractor
from scrapy.selector import HtmlXPathSelector
from testspiders.items import TestspidersItem
from scrapy.exceptions import CloseSpider


class MySpider(CrawlSpider):
    name = "crawler1"
    pageLimit=200
    allowed_domains = ["dice.com"]
    start_urls = ["https://www.dice.com/jobs?q=Computer+science&l=Philadelphia%2C+PA&searchid=4203982346226"]
    rules = (
        Rule(SgmlLinkExtractor(), callback="parse_items", follow= True),
    )

    def parse_items(self, response):
        hxs = HtmlXPathSelector(response)
        #titles = hxs.xpath("//div[@class = 'row result']")
        #titles = hxs.xpath('//a/')
        #titles = hxs.select("//h3/a/")
		#titles = hxs.select("//div[@id='serp']")
        titles = hxs.select("//div[@class='serp-result-content']")
        parenturl = response.request.url

        if self.pageLimit <= 0:
            raise CloseSpider('Limit Reached')          
      
        if len(titles) >= self.pageLimit:
            titles=list(titles)[:self.pageLimit]
            self.pageLimit=0
        else:
            self.pageLimit=self.pageLimit-len(titles)
        for titles in titles:
            item = TestspidersItem()
            #item["title"] = titles.xpath("a/@title").extract()
            #item["link"] = "http://www.indeed.com/jobs?q=jobs&l=Philadelphia%2C+PA"+"".join(titles.xpath("a/@href").extract())
            item["title"] = titles.select("h3/a/@title").extract()
            #item["link"] = "https://www.dice.com/jobs?q=Computer+science&l=Philadelphia%2C+PA&searchid=4203982346226"+"".join(titles.select("h3/a/@href").extract())
            item["link"] = "".join(titles.select("h3/a/@href").extract())
            item["parent"] = parenturl
            yield item